Icons from:
http://game-icons.net/lorc/originals/drink-me.html